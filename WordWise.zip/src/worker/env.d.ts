// Extend the Env interface to include OPENAI_API_KEY
declare global {
  interface Env {
    OPENAI_API_KEY: string;
    DB: D1Database;
  }
}

export {};
