import { Hono } from "hono";
import { cors } from "hono/cors";
import OpenAI from "openai";
import { WordSchema, HintRequestSchema, HintResponseSchema } from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

// Get a random word for the game
app.get("/api/word", async (c) => {
  try {
    const db = c.env.DB;
    const result = await db.prepare("SELECT * FROM words ORDER BY RANDOM() LIMIT 1").first();
    
    if (!result) {
      return c.json({ error: "No words found" }, 404);
    }

    const word = WordSchema.parse(result);
    return c.json(word);
  } catch (error) {
    console.error("Error fetching word:", error);
    return c.json({ error: "Failed to fetch word" }, 500);
  }
});

// Get an AI-powered hint for the current word
app.post("/api/hint", async (c) => {
  try {
    const body = await c.req.json();
    const { word, category, guessedLetters } = HintRequestSchema.parse(body);

    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const revealedLetters = word
      .split("")
      .map(letter => guessedLetters.includes(letter.toUpperCase()) ? letter : "_")
      .join(" ");

    const prompt = `You are helping a student in a word guessing game. Create ONE SUPER SMART HINT that is extremely close to the answer and makes it very easy to guess the word.

WORD TO GUESS: ${word}
CATEGORY: ${category || "General"}
CURRENT PROGRESS: ${revealedLetters}
LETTERS ALREADY TRIED: ${guessedLetters.join(", ") || "None"}

HINT REQUIREMENTS:
1. ALWAYS START with the TYPE in ALL CAPS (FOOD, DRINK, ANIMAL, OBJECT, PLACE, SPORT, etc.)
2. Make the hint EXTREMELY specific and close to the answer
3. Use ONE clear, engaging sentence that almost gives away the answer
4. Include the most distinctive features, colors, uses, or characteristics
5. Make it so specific that guessing becomes very easy
6. Be helpful and encouraging to the player

NEVER MENTION:
- Any letters in the word
- Number of letters or syllables
- Words that rhyme with the target word

EXAMPLES OF SUPER SMART HINTS:
- For "chocolate": "FOOD: Sweet brown treat made from cocoa beans that melts in your mouth, loved by everyone during celebrations and comes in bars, candies, and hot drinks."
- For "computer": "ELECTRONIC DEVICE: Machine with screen and keyboard that you use to browse the internet, type documents, play games, and video call with friends."
- For "apple": "FRUIT: Red or green round fruit that people say keeps the doctor away when eaten daily, grows on trees and makes a crunching sound when you bite it."
- For "elephant": "ANIMAL: Largest land animal with gray wrinkled skin, long trunk for grabbing things, big floppy ears, and white tusks."
- For "pizza": "FOOD: Round Italian dish with cheese and tomato sauce on dough base, cut into triangular slices and delivered in boxes."
- For "guitar": "MUSICAL INSTRUMENT: Wooden object with six strings that you strum or pluck to make music in rock and pop songs."
- For "bicycle": "VEHICLE: Two-wheeled transport with pedals you push with your feet to move forward, has handlebars to steer."
- For "banana": "FRUIT: Long curved yellow fruit with peel you remove before eating, monkeys love these and they're great in smoothies."

Provide ONLY the smart hint starting with the TYPE in ALL CAPS, nothing else:`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 150,
      temperature: 0.7,
    });

    const hint = response.choices[0]?.message?.content?.trim() || "This is a wonderful word that you can figure out!";
    
    const hintResponse = HintResponseSchema.parse({ hint });
    return c.json(hintResponse);
  } catch (error) {
    console.error("Error generating hint:", error);
    return c.json({ 
      hint: "Keep trying! You're doing great! Think about what this word might mean." 
    });
  }
});

export default app;
