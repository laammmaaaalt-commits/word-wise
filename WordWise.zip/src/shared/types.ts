import z from "zod";

export const WordSchema = z.object({
  id: z.number(),
  word: z.string(),
  category: z.string().nullable(),
  difficulty: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type WordType = z.infer<typeof WordSchema>;

export const GameStateSchema = z.object({
  word: z.string(),
  guessedLetters: z.array(z.string()),
  wrongGuesses: z.number(),
  maxGuesses: z.number(),
  category: z.string().nullable(),
  difficulty: z.string().nullable(),
  isComplete: z.boolean(),
  isWon: z.boolean(),
});

export type GameStateType = z.infer<typeof GameStateSchema>;

export const HintRequestSchema = z.object({
  word: z.string(),
  category: z.string().nullable(),
  guessedLetters: z.array(z.string()),
});

export type HintRequestType = z.infer<typeof HintRequestSchema>;

export const HintResponseSchema = z.object({
  hint: z.string(),
});

export type HintResponseType = z.infer<typeof HintResponseSchema>;
