import { useEffect } from "react";
import { useGame } from "@/react-app/hooks/useGame";
import WordDisplay from "@/react-app/components/WordDisplay";
import LetterInput from "@/react-app/components/LetterInput";
import GameStats from "@/react-app/components/GameStats";
import HintSection from "@/react-app/components/HintSection";
import SkipButton from "@/react-app/components/SkipButton";
import GameResult from "@/react-app/components/GameResult";
import { Loader2, Sparkles } from "lucide-react";

export default function Home() {
  const {
    gameState,
    loading,
    hint,
    hintLoading,
    startNewGame,
    guessLetter,
    getHint,
    getDisplayWord,
    getRemainingGuesses,
    skipWord,
  } = useGame();

  useEffect(() => {
    // Add Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Fredoka+One:wght@400&family=Nunito:wght@400;600;700;800&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    // Start the first game
    startNewGame();
  }, [startNewGame]);

  if (loading && !gameState) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin mb-4">
            <Loader2 className="w-12 h-12 text-purple-600 mx-auto" />
          </div>
          <p className="text-xl font-semibold text-purple-700">Loading your word...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-50 to-indigo-100" style={{ fontFamily: "'Nunito', sans-serif" }}>
      {/* Header */}
      <div className="text-center py-8">
        <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 bg-clip-text text-transparent mb-4" style={{ fontFamily: "'Fredoka One', cursive" }}>
          WordWise
        </h1>
        <div className="flex items-center justify-center gap-2 text-lg text-gray-700 font-medium">
          <Sparkles className="w-5 h-5 text-yellow-500" />
          <span>Fun Word Guessing with AI Hints!</span>
          <Sparkles className="w-5 h-5 text-yellow-500" />
        </div>
      </div>

      <div className="container mx-auto px-4 pb-8">
        {gameState && (
          <>
            {/* Game Stats */}
            <GameStats
              remainingGuesses={getRemainingGuesses()}
              maxGuesses={gameState.maxGuesses}
              wrongGuesses={gameState.wrongGuesses}
            />

            {/* Word Display */}
            <WordDisplay
              displayWord={getDisplayWord()}
              category={gameState.category}
              difficulty={gameState.difficulty}
              showDetails={!!hint}
            />

            {/* Game Complete Screen */}
            {gameState.isComplete ? (
              <GameResult
                isWon={gameState.isWon}
                word={gameState.word}
                onPlayAgain={startNewGame}
              />
            ) : (
              <>
                {/* Hint Section */}
                <HintSection
                  hint={hint}
                  onGetHint={getHint}
                  hintLoading={hintLoading}
                  isGameComplete={gameState.isComplete}
                />

                {/* Skip Button */}
                <SkipButton
                  onSkip={skipWord}
                  loading={loading}
                  isGameComplete={gameState.isComplete}
                />

                {/* Letter Input */}
                <LetterInput
                  onGuessLetter={guessLetter}
                  guessedLetters={gameState.guessedLetters}
                  isGameComplete={gameState.isComplete}
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
