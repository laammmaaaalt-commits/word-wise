import { useState, useCallback } from "react";
import { GameStateType, WordType, HintResponseType } from "@/shared/types";

const MAX_WRONG_GUESSES = 6;

export function useGame() {
  const [gameState, setGameState] = useState<GameStateType | null>(null);
  const [currentWord, setCurrentWord] = useState<WordType | null>(null);
  const [loading, setLoading] = useState(false);
  const [hint, setHint] = useState<string>("");
  const [hintLoading, setHintLoading] = useState(false);

  const startNewGame = useCallback(async () => {
    setLoading(true);
    setHint(""); // Clear any previous hint
    setHintLoading(false); // Reset hint loading state
    try {
      const response = await fetch("/api/word");
      if (!response.ok) throw new Error("Failed to fetch word");
      
      const word: WordType = await response.json();
      setCurrentWord(word);
      
      setGameState({
        word: word.word,
        guessedLetters: [],
        wrongGuesses: 0,
        maxGuesses: MAX_WRONG_GUESSES,
        category: word.category,
        difficulty: word.difficulty,
        isComplete: false,
        isWon: false,
      });
    } catch (error) {
      console.error("Error starting game:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  const guessLetter = useCallback((letter: string) => {
    if (!gameState || gameState.isComplete) return;
    
    const upperLetter = letter.toUpperCase();
    
    // Don't allow duplicate guesses
    if (gameState.guessedLetters.includes(upperLetter)) return;
    
    const newGuessedLetters = [...gameState.guessedLetters, upperLetter];
    const isCorrectGuess = gameState.word.toUpperCase().includes(upperLetter);
    const newWrongGuesses = isCorrectGuess ? gameState.wrongGuesses : gameState.wrongGuesses + 1;
    
    // Check if word is complete
    const wordLetters = gameState.word.toUpperCase().split("");
    const isWordComplete = wordLetters.every(letter => newGuessedLetters.includes(letter));
    
    // Check if game is over
    const isGameOver = newWrongGuesses >= MAX_WRONG_GUESSES;
    const isComplete = isWordComplete || isGameOver;
    
    setGameState({
      ...gameState,
      guessedLetters: newGuessedLetters,
      wrongGuesses: newWrongGuesses,
      isComplete,
      isWon: isWordComplete,
    });

    // Clear hint when game is complete
    if (isComplete) {
      setHint("");
    }
  }, [gameState]);

  const getHint = useCallback(async () => {
    if (!gameState || !currentWord || hintLoading) return;
    
    setHintLoading(true);
    try {
      const response = await fetch("/api/hint", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          word: gameState.word,
          category: gameState.category,
          guessedLetters: gameState.guessedLetters,
        }),
      });
      
      if (!response.ok) throw new Error("Failed to get hint");
      
      const hintResponse: HintResponseType = await response.json();
      setHint(hintResponse.hint);
    } catch (error) {
      console.error("Error getting hint:", error);
      setHint("Keep trying! You're doing great!");
    } finally {
      setHintLoading(false);
    }
  }, [gameState, currentWord, hintLoading]);

  const getDisplayWord = useCallback(() => {
    if (!gameState) return "";
    
    return gameState.word
      .split("")
      .map(letter => 
        gameState.guessedLetters.includes(letter.toUpperCase()) ? letter : "_"
      )
      .join(" ");
  }, [gameState]);

  const getRemainingGuesses = useCallback(() => {
    return gameState ? gameState.maxGuesses - gameState.wrongGuesses : 0;
  }, [gameState]);

  const skipWord = useCallback(async () => {
    if (!gameState || gameState.isComplete || loading) return;
    
    // Start a new game directly
    await startNewGame();
  }, [gameState, loading, startNewGame]);

  return {
    gameState,
    loading,
    hint,
    hintLoading,
    startNewGame,
    guessLetter,
    getHint,
    getDisplayWord,
    getRemainingGuesses,
    skipWord,
  };
}
