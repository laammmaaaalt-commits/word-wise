interface WordDisplayProps {
  displayWord: string;
  category: string | null;
  difficulty: string | null;
  showDetails: boolean;
}

export default function WordDisplay({ displayWord, category, difficulty, showDetails }: WordDisplayProps) {
  return (
    <div className="text-center mb-8">
      {showDetails && (
        <div className="flex justify-center items-center gap-2 mb-4">
          {category && (
            <span className="px-3 py-1 bg-purple-100 text-purple-700 text-sm font-medium rounded-full">
              {category}
            </span>
          )}
          {difficulty && (
            <span className={`px-3 py-1 text-sm font-medium rounded-full ${
              difficulty === 'easy' ? 'bg-green-100 text-green-700' :
              difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
              'bg-red-100 text-red-700'
            }`}>
              {difficulty}
            </span>
          )}
        </div>
      )}
      
      <div className="text-4xl md:text-6xl font-bold text-gray-800 tracking-wider font-mono bg-white p-6 rounded-2xl shadow-lg border-2 border-blue-200">
        {displayWord || "_ _ _ _ _"}
      </div>
    </div>
  );
}
