import { Lightbulb, Loader2 } from "lucide-react";

interface HintSectionProps {
  hint: string;
  onGetHint: () => void;
  hintLoading: boolean;
  isGameComplete: boolean;
}

export default function HintSection({ hint, onGetHint, hintLoading, isGameComplete }: HintSectionProps) {
  return (
    <div className="mb-8">
      <div className="text-center mb-4">
        <button
          onClick={onGetHint}
          disabled={hintLoading || isGameComplete}
          className={`
            px-6 py-3 rounded-2xl font-bold text-lg transition-all duration-200 transform
            ${
              hintLoading || isGameComplete
                ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                : "bg-gradient-to-r from-pink-400 to-pink-600 text-white hover:from-pink-500 hover:to-pink-700 hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl"
            }
          `}
        >
          {hintLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin" />
              Getting Hint...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5" />
              Get AI Hint
            </div>
          )}
        </button>
      </div>
      
      {hint && (
        <div className="bg-gradient-to-r from-pink-50 to-pink-50 border-2 border-pink-200 p-6 rounded-2xl shadow-lg max-w-2xl mx-auto">
          <div className="flex items-start gap-3">
            <Lightbulb className="w-6 h-6 text-pink-600 mt-1 flex-shrink-0" />
            <p className="text-gray-800 text-lg leading-relaxed">{hint}</p>
          </div>
        </div>
      )}
    </div>
  );
}
