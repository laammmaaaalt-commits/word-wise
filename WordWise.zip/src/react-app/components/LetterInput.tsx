import { useState, useEffect } from "react";

interface LetterInputProps {
  onGuessLetter: (letter: string) => void;
  guessedLetters: string[];
  isGameComplete: boolean;
}

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

export default function LetterInput({ onGuessLetter, guessedLetters, isGameComplete }: LetterInputProps) {
  const [selectedLetter, setSelectedLetter] = useState("");

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (isGameComplete) return;
      
      const letter = event.key.toUpperCase();
      if (ALPHABET.includes(letter) && !guessedLetters.includes(letter)) {
        onGuessLetter(letter);
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [onGuessLetter, guessedLetters, isGameComplete]);

  const handleLetterClick = (letter: string) => {
    if (!guessedLetters.includes(letter) && !isGameComplete) {
      onGuessLetter(letter);
      setSelectedLetter(letter);
      setTimeout(() => setSelectedLetter(""), 200);
    }
  };

  return (
    <div className="mb-8">
      <p className="text-center text-gray-600 mb-4">Click a letter or use your keyboard!</p>
      <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-13 gap-2 max-w-4xl mx-auto">
        {ALPHABET.map((letter) => {
          const isGuessed = guessedLetters.includes(letter);
          const isSelected = selectedLetter === letter;
          
          return (
            <button
              key={letter}
              onClick={() => handleLetterClick(letter)}
              disabled={isGuessed || isGameComplete}
              className={`
                w-10 h-10 sm:w-12 sm:h-12 rounded-lg font-bold text-lg transition-all duration-200 transform
                ${
                  isGuessed
                    ? "bg-gray-200 text-gray-500 cursor-not-allowed scale-95"
                    : isGameComplete
                    ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                    : "bg-gradient-to-br from-blue-400 to-purple-500 text-white hover:from-blue-500 hover:to-purple-600 hover:scale-110 active:scale-95 shadow-lg hover:shadow-xl cursor-pointer"
                }
                ${isSelected ? "animate-pulse scale-110" : ""}
              `}
            >
              {letter}
            </button>
          );
        })}
      </div>
    </div>
  );
}
