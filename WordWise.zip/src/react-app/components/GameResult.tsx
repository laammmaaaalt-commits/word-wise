import { Trophy, RotateCcw, Frown } from "lucide-react";

interface GameResultProps {
  isWon: boolean;
  word: string;
  onPlayAgain: () => void;
}

export default function GameResult({ isWon, word, onPlayAgain }: GameResultProps) {
  return (
    <div className="text-center">
      <div className={`p-8 rounded-3xl shadow-xl mb-6 ${
        isWon 
          ? "bg-gradient-to-br from-green-100 to-emerald-100 border-2 border-green-300" 
          : "bg-gradient-to-br from-red-100 to-pink-100 border-2 border-red-300"
      }`}>
        <div className="mb-4">
          {isWon ? (
            <Trophy className="w-16 h-16 text-yellow-500 mx-auto animate-bounce" />
          ) : (
            <Frown className="w-16 h-16 text-red-500 mx-auto" />
          )}
        </div>
        
        <h2 className={`text-3xl font-bold mb-4 ${
          isWon ? "text-green-800" : "text-red-800"
        }`}>
          {isWon ? "Congratulations! 🎉" : "Game Over! 😔"}
        </h2>
        
        <p className={`text-xl mb-4 ${
          isWon ? "text-green-700" : "text-red-700"
        }`}>
          {isWon 
            ? "You guessed the word!" 
            : `The word was: ${word}`
          }
        </p>
        
        {isWon && (
          <p className="text-green-600 text-lg mb-6">
            Great job! You're getting really good at this! 🌟
          </p>
        )}
        
        {!isWon && (
          <p className="text-red-600 text-lg mb-6">
            Don't give up! Try again and you'll get it next time! 💪
          </p>
        )}
      </div>
      
      <button
        onClick={onPlayAgain}
        className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold text-xl rounded-2xl shadow-lg hover:from-blue-600 hover:to-purple-700 hover:scale-105 active:scale-95 transition-all duration-200 transform"
      >
        <div className="flex items-center gap-3">
          <RotateCcw className="w-6 h-6" />
          Play Again
        </div>
      </button>
    </div>
  );
}
