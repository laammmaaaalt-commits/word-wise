import { Heart, HeartOff } from "lucide-react";

interface GameStatsProps {
  remainingGuesses: number;
  maxGuesses: number;
  wrongGuesses: number;
}

export default function GameStats({ remainingGuesses, maxGuesses, wrongGuesses }: GameStatsProps) {
  return (
    <div className="flex justify-center items-center mb-6">
      <div className="bg-white p-4 rounded-2xl shadow-lg border-2 border-red-200">
        <div className="text-center mb-2">
          <span className="text-sm font-medium text-gray-600">Lives Remaining</span>
        </div>
        <div className="flex items-center justify-center gap-1">
          {Array.from({ length: maxGuesses }, (_, index) => {
            const isLost = index < wrongGuesses;
            return isLost ? (
              <HeartOff key={index} className="w-6 h-6 text-gray-300" />
            ) : (
              <Heart key={index} className="w-6 h-6 text-red-500 fill-current" />
            );
          })}
        </div>
        <div className="text-center mt-2">
          <span className={`text-lg font-bold ${
            remainingGuesses <= 2 ? 'text-red-600' : 
            remainingGuesses <= 4 ? 'text-yellow-600' : 'text-green-600'
          }`}>
            {remainingGuesses}
          </span>
        </div>
      </div>
    </div>
  );
}
