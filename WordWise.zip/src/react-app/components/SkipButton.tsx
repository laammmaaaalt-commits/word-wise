import { SkipForward, Loader2 } from "lucide-react";

interface SkipButtonProps {
  onSkip: () => void;
  loading: boolean;
  isGameComplete: boolean;
}

export default function SkipButton({ onSkip, loading, isGameComplete }: SkipButtonProps) {
  return (
    <div className="text-center mb-6">
      <button
        onClick={onSkip}
        disabled={loading || isGameComplete}
        className={`
          px-6 py-3 rounded-2xl font-bold text-lg transition-all duration-200 transform
          ${
            loading || isGameComplete
              ? "bg-gray-200 text-gray-500 cursor-not-allowed"
              : "bg-gradient-to-r from-pink-400 to-pink-600 text-white hover:from-pink-500 hover:to-pink-700 hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl"
          }
        `}
        title="Skip this word and move to the next one"
      >
        {loading ? (
          <div className="flex items-center gap-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            Loading...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <SkipForward className="w-5 h-5" />
            Skip
          </div>
        )}
      </button>
    </div>
  );
}
