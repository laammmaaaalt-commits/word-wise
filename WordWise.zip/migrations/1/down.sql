
DROP INDEX idx_words_difficulty;
DROP INDEX idx_words_category;
DROP TABLE words;
