
CREATE TABLE words (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  word TEXT NOT NULL,
  category TEXT,
  difficulty TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_words_category ON words(category);
CREATE INDEX idx_words_difficulty ON words(difficulty);

INSERT INTO words (word, category, difficulty) VALUES
('RAINBOW', 'nature', 'easy'),
('ELEPHANT', 'animals', 'medium'),
('BUTTERFLY', 'animals', 'medium'),
('SUNSHINE', 'nature', 'easy'),
('CHOCOLATE', 'food', 'medium'),
('COMPUTER', 'technology', 'medium'),
('FRIENDSHIP', 'emotions', 'hard'),
('MOUNTAIN', 'nature', 'easy'),
('ADVENTURE', 'activities', 'hard'),
('DINOSAUR', 'animals', 'medium'),
('PIZZA', 'food', 'easy'),
('ROCKET', 'technology', 'easy'),
('GALAXY', 'space', 'medium'),
('TREASURE', 'adventure', 'medium'),
('OCEAN', 'nature', 'easy'),
('CASTLE', 'buildings', 'easy'),
('MAGIC', 'fantasy', 'easy'),
('JUNGLE', 'nature', 'easy'),
('ROBOT', 'technology', 'easy'),
('DRAGON', 'fantasy', 'easy');
